# Parts Desk — Quote-to-Delivery Workflow

An independent business analysis and implementation case study for spare-parts quotation, approval and fulfilment. The application translates compatibility, pricing and stock rules into a usable workflow with an audit history.

**All buyers, models, parts, prices and compatibility mappings are fictional. This is a local demonstration, not an operational sales or tax system.**

## Run

Python 3.11+; no external dependencies.

```bash
python -m unittest discover -s tests -v
python -m parts_workflow
```

Open http://127.0.0.1:8765. To use another database or port: `python -m parts_workflow --db data/another.db --port 8766`.

## Walkthrough

1. Choose SIM-A100 and a compatible part.
2. Create a quotation for two P-101 units with 5% discount, ₹100 shipping and 18% demo tax. Expected total: ₹2,920.50.
3. Approve the quote; available stock decreases because units are reserved.
4. Move to ORDERED and DISPATCHED; dispatch consumes the reserved physical stock once.
5. Confirm DELIVERED and review the timestamped event trail.
6. Attempt an incompatible part through the API or request more available stock; validation rejects it.

## What this demonstrates

Business rules, user stories, acceptance criteria, process transitions, exception handling, relational data, API validation, concurrency controls and traceable tests. [Requirements and process](docs/business-analysis.md) · [API and data](docs/api.md) · [UAT](docs/uat.md).

Implementation: Python standard library, SQLite, HTML, CSS and JavaScript. Pricing uses integer paisa and explicit rounding. Approval reserves stock inside a write transaction. Duplicate request retries return the original quote; changed requests cannot reuse the same idempotency key.

## Boundaries

Single part per quote, one stock location, no payment, real shipping, external inventory integration or actual invoicing. Tax is an editable arithmetic assumption, not verified GST treatment. The local server binds to 127.0.0.1 and has no user authentication; do not expose it publicly or enter customer personal data. A production version needs authenticated roles, approval permissions, database backups, monitoring and integration testing. Catalogue values are initialised once; use a new database file for a clean demonstration.

## Online project

[Portfolio and interactive demonstrations](https://nikunjgalaiya.github.io/) · [Source repository](https://github.com/nikunjgalaiya/spare-parts-order-workflow)
