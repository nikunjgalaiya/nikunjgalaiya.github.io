"""A fictional spare-parts quotation and fulfilment workflow."""
