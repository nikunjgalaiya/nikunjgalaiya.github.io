import hashlib
import json
import sqlite3
import uuid
from datetime import date, timedelta, datetime, timezone

class RuleError(ValueError):
    pass

CATALOG = [
    ("P-101","Feed assembly","SIM-A100",125000,80000,12),
    ("P-102","Drive belt","SIM-A100",95000,58000,30),
    ("P-103","Nozzle set","SIM-A100",65000,35000,20),
    ("P-201","Feed assembly","SIM-B200",180000,125000,8),
    ("P-202","Control board","SIM-B200",220000,160000,4),
]
TRANSITIONS={
    "DRAFT":{"APPROVED","CANCELLED"},"APPROVED":{"ORDERED","CANCELLED"},
    "ORDERED":{"DISPATCHED","CANCELLED"},"DISPATCHED":{"DELIVERED"},
    "DELIVERED":set(),"CANCELLED":set()
}

def connect(path):
    c=sqlite3.connect(path,timeout=10,isolation_level=None)
    c.row_factory=sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    return c

def init_db(c):
    c.executescript("""
    CREATE TABLE IF NOT EXISTS parts(
      part_id TEXT PRIMARY KEY,name TEXT,machine_model TEXT,
      unit_price_paisa INTEGER,unit_cost_paisa INTEGER,
      on_hand INTEGER CHECK(on_hand>=0),reserved INTEGER DEFAULT 0 CHECK(reserved>=0 AND reserved<=on_hand)
    );
    CREATE TABLE IF NOT EXISTS quotes(
      quote_id TEXT PRIMARY KEY,idempotency_key TEXT UNIQUE,request_hash TEXT,
      buyer_reference TEXT,part_id TEXT REFERENCES parts(part_id),machine_model TEXT,
      quantity INTEGER,discount_bps INTEGER,tax_bps INTEGER,shipping_paisa INTEGER,
      merchandise_paisa INTEGER,discount_paisa INTEGER,tax_paisa INTEGER,
      total_paisa INTEGER,unit_cost_paisa INTEGER,status TEXT,created_date TEXT,expires_date TEXT
    );
    CREATE TABLE IF NOT EXISTS events(
      event_id INTEGER PRIMARY KEY,quote_id TEXT REFERENCES quotes(quote_id),
      from_status TEXT,to_status TEXT,event_time TEXT,note TEXT
    );
    """)
    c.executemany("INSERT OR IGNORE INTO parts(part_id,name,machine_model,unit_price_paisa,unit_cost_paisa,on_hand) VALUES (?,?,?,?,?,?)",CATALOG)

def integer(payload,key,low,high,default=None):
    v=payload.get(key,default)
    if type(v) is not int or not low<=v<=high:
        raise RuleError(f"{key} must be an integer between {low} and {high}")
    return v

def catalog(c):
    return [dict(r) for r in c.execute("SELECT *,on_hand-reserved available FROM parts ORDER BY part_id")]

def quote(c,qid):
    row=c.execute("SELECT q.*,p.name FROM quotes q JOIN parts p USING(part_id) WHERE quote_id=?",(qid,)).fetchone()
    if not row:raise RuleError("Quote not found")
    r=dict(row)
    for key in ["request_hash","idempotency_key"]:r.pop(key)
    r["events"]=[dict(e) for e in c.execute("SELECT from_status,to_status,event_time,note FROM events WHERE quote_id=? ORDER BY event_id",(qid,))]
    return r

def event(c,qid,old,new,note=""):
    c.execute("INSERT INTO events(quote_id,from_status,to_status,event_time,note) VALUES(?,?,?,?,?)",
      (qid,old,new,datetime.now(timezone.utc).isoformat(timespec="seconds"),note))

def create_quote(c,payload,today=None):
    today=today or date.today()
    if not isinstance(payload,dict):raise RuleError("JSON object required")
    allowed={"buyer_reference","part_id","machine_model","quantity","discount_bps","tax_bps","shipping_paisa","idempotency_key"}
    if set(payload)-allowed:raise RuleError("Unexpected request fields")
    qty=integer(payload,"quantity",1,1000)
    discount=integer(payload,"discount_bps",0,1000,0)
    tax=integer(payload,"tax_bps",0,10000,1800)
    shipping=integer(payload,"shipping_paisa",0,1000000,10000)
    buyer=payload.get("buyer_reference","")
    key=payload.get("idempotency_key","")
    if not isinstance(buyer,str) or not 1<=len(buyer.strip())<=60:raise RuleError("Buyer reference must contain 1 to 60 characters")
    if not isinstance(key,str) or not 8<=len(key)<=100:raise RuleError("An idempotency key of 8 to 100 characters is required")
    for k in ["part_id","machine_model"]:
        if not isinstance(payload.get(k),str):raise RuleError(f"{k} must be text")
    digest=hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(",",":")).encode()).hexdigest()
    c.execute("BEGIN IMMEDIATE")
    try:
        old=c.execute("SELECT quote_id,request_hash FROM quotes WHERE idempotency_key=?",(key,)).fetchone()
        if old:
            if old["request_hash"]!=digest:raise RuleError("Idempotency key was already used for a different request")
            c.commit();return quote(c,old["quote_id"])
        part=c.execute("SELECT * FROM parts WHERE part_id=?",(payload["part_id"],)).fetchone()
        if not part:raise RuleError("Unknown part")
        if payload["machine_model"]!=part["machine_model"]:raise RuleError("Part is incompatible with the selected machine model")
        merchandise=part["unit_price_paisa"]*qty
        discount_amount=(merchandise*discount+5000)//10000
        taxable=merchandise-discount_amount+shipping
        tax_amount=(taxable*tax+5000)//10000
        qid="Q-"+uuid.uuid4().hex[:12].upper()
        c.execute("INSERT INTO quotes VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",(
          qid,key,digest,buyer.strip(),part["part_id"],payload["machine_model"],qty,discount,tax,shipping,
          merchandise,discount_amount,tax_amount,taxable+tax_amount,part["unit_cost_paisa"],"DRAFT",
          today.isoformat(),(today+timedelta(days=7)).isoformat()))
        event(c,qid,None,"DRAFT","Prices frozen when the quote is created")
        c.commit();return quote(c,qid)
    except Exception:
        c.rollback();raise

def transition(c,qid,new,today=None):
    today=today or date.today()
    c.execute("BEGIN IMMEDIATE")
    try:
        q=c.execute("SELECT * FROM quotes WHERE quote_id=?",(qid,)).fetchone()
        if not q:raise RuleError("Quote not found")
        old=q["status"]
        if new not in TRANSITIONS[old]:raise RuleError(f"Cannot move from {old} to {new}")
        part=c.execute("SELECT * FROM parts WHERE part_id=?",(q["part_id"],)).fetchone()
        if new=="APPROVED":
            if today.isoformat()>q["expires_date"]:raise RuleError("Quote has expired; create a new quote")
            if part["on_hand"]-part["reserved"]<q["quantity"]:raise RuleError("Insufficient available stock")
            c.execute("UPDATE parts SET reserved=reserved+? WHERE part_id=?",(q["quantity"],q["part_id"]))
        if new=="CANCELLED" and old in {"APPROVED","ORDERED"}:
            c.execute("UPDATE parts SET reserved=reserved-? WHERE part_id=?",(q["quantity"],q["part_id"]))
        if new=="DISPATCHED":
            c.execute("UPDATE parts SET reserved=reserved-?,on_hand=on_hand-? WHERE part_id=?",
              (q["quantity"],q["quantity"],q["part_id"]))
        c.execute("UPDATE quotes SET status=? WHERE quote_id=?",(new,qid))
        event(c,qid,old,new)
        c.commit();return quote(c,qid)
    except Exception:
        c.rollback();raise

def list_quotes(c):
    ids=[r[0] for r in c.execute("SELECT quote_id FROM quotes ORDER BY rowid DESC LIMIT 100")]
    return [quote(c,qid) for qid in ids]
