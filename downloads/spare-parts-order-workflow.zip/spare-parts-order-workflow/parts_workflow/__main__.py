import argparse
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse
from .core import RuleError,catalog,connect,create_quote,init_db,list_quotes,transition

ROOT=Path(__file__).resolve().parents[1]

def make_handler(db_path):
    class Handler(BaseHTTPRequestHandler):
        def response(self,status,data,kind="application/json"):
            body=json.dumps(data).encode() if kind=="application/json" else data
            self.send_response(status)
            self.send_header("Content-Type",kind+"; charset=utf-8")
            self.send_header("Content-Length",str(len(body)))
            self.send_header("X-Content-Type-Options","nosniff")
            self.end_headers();self.wfile.write(body)

        def do_GET(self):
            path=urlparse(self.path).path
            with connect(db_path) as c:
                if path=="/api/catalog":return self.response(200,catalog(c))
                if path=="/api/quotes":return self.response(200,list_quotes(c))
            files={"/":("index.html","text/html"),"/app.js":("app.js","text/javascript"),"/style.css":("style.css","text/css")}
            if path in files:
                name,kind=files[path];return self.response(200,(ROOT/"web"/name).read_bytes(),kind)
            return self.response(404,{"error":"Not found"})

        def do_POST(self):
            # Requests from a different web origin cannot mutate the local demo.
            origin=self.headers.get("Origin")
            if origin and urlparse(origin).netloc!=self.headers.get("Host"):
                return self.response(403,{"error":"Origin does not match this local app"})
            if self.headers.get("Content-Type","").split(";")[0]!="application/json":
                return self.response(415,{"error":"Use application/json"})
            try:
                size=int(self.headers.get("Content-Length","0"))
                if size<=0 or size>16384:raise RuleError("Body must contain 1 to 16384 bytes")
                payload=json.loads(self.rfile.read(size))
                if not isinstance(payload,dict):raise RuleError("JSON object required")
                path=urlparse(self.path).path
                with connect(db_path) as c:
                    if path=="/api/quotes":return self.response(201,create_quote(c,payload))
                    tokens=path.strip("/").split("/")
                    if len(tokens)==4 and tokens[:2]==["api","quotes"] and tokens[3]=="status":
                        return self.response(200,transition(c,tokens[2],payload.get("status")))
                self.response(404,{"error":"Not found"})
            except (RuleError,ValueError,TypeError,json.JSONDecodeError) as e:
                self.response(422,{"error":str(e)})
        def log_message(self,*args):
            pass
    return Handler

def main():
    p=argparse.ArgumentParser(description="Run the spare-parts workflow demonstration")
    p.add_argument("--db",type=Path,default=ROOT/"data/demo.db")
    p.add_argument("--port",type=int,default=8765)
    a=p.parse_args();a.db.parent.mkdir(parents=True,exist_ok=True)
    with connect(a.db) as c:init_db(c)
    server=ThreadingHTTPServer(("127.0.0.1",a.port),make_handler(a.db))
    print(f"Open http://127.0.0.1:{a.port} — synthetic local demonstration",flush=True)
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:server.server_close()

if __name__=="__main__":main()
