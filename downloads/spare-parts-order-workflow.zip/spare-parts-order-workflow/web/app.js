let parts=[],requestKey=null;
const $=id=>document.getElementById(id);
const currency=new Intl.NumberFormat('en-IN',{style:'currency',currency:'INR'});
const money=p=>currency.format(p/100);
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const next={DRAFT:['APPROVED','Approve quote'],APPROVED:['ORDERED','Create order'],ORDERED:['DISPATCHED','Mark dispatched'],DISPATCHED:['DELIVERED','Confirm delivered']};
async function api(path,body){
 const response=await fetch(path,body?{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}:{});
 const result=await response.json();if(!response.ok)throw Error(result.error||'Request failed');return result;
}
function options(){
 const selected=$('part').value,model=$('model').value;
 $('part').innerHTML=parts.filter(p=>p.machine_model===model).map(p=>'<option value="'+esc(p.part_id)+'">'+esc(p.name)+' — '+money(p.unit_price_paisa)+'</option>').join('');
 if(parts.some(p=>p.part_id===selected&&p.machine_model===model))$('part').value=selected;
}
async function refresh(){
 const [catalog,quotes]=await Promise.all([api('/api/catalog'),api('/api/quotes')]);parts=catalog;options();
 const open=quotes.filter(q=>!['DELIVERED','CANCELLED'].includes(q.status));
 $('stats').innerHTML=[['Open quotations',open.length],['Reserved units',parts.reduce((a,p)=>a+p.reserved,0)],['Delivered orders',quotes.filter(q=>q.status==='DELIVERED').length]].map(x=>'<div class="stat"><span>'+x[0]+'</span><strong>'+x[1]+'</strong></div>').join('');
 $('stock').innerHTML=parts.map(p=>'<tr><td>'+esc(p.name)+'</td><td>'+esc(p.machine_model)+'</td><td>'+money(p.unit_price_paisa)+'</td><td>'+p.on_hand+'</td><td>'+p.reserved+'</td><td>'+p.available+'</td></tr>').join('');
 $('quotes').innerHTML=quotes.map(q=>{
 const action=next[q.status],canCancel=['DRAFT','APPROVED','ORDERED'].includes(q.status);
 return '<article class="quote"><div class="quote-head"><strong>'+esc(q.buyer_reference)+'</strong><span class="status">'+q.status+'</span></div><div class="qid">'+q.quote_id+'</div><div class="amount">'+money(q.total_paisa)+'</div><div class="quote-meta">'+esc(q.name)+' × '+q.quantity+' · '+esc(q.machine_model)+'<br>Tax '+money(q.tax_paisa)+' · Shipping '+money(q.shipping_paisa)+' · Valid through '+q.expires_date+'</div><div class="actions">'+(action?'<button class="action" data-id="'+q.quote_id+'" data-status="'+action[0]+'">'+action[1]+'</button>':'')+(canCancel?'<button class="action cancel" data-id="'+q.quote_id+'" data-status="CANCELLED">Cancel</button>':'')+'</div><details><summary>Order history</summary><ol>'+q.events.map(e=>'<li>'+esc(e.to_status)+' · '+esc(e.event_time)+(e.note?' · '+esc(e.note):'')+'</li>').join('')+'</ol></details></article>';
 }).join('')||'<p class="empty">Create your first quotation to begin the workflow.</p>';
}
$('model').addEventListener('change',options);
$('quote-form').addEventListener('input',()=>requestKey=null);
$('quote-form').addEventListener('submit',async event=>{
 event.preventDefault();$('error').textContent='';$('create').disabled=true;
 requestKey=requestKey||(crypto.randomUUID?crypto.randomUUID():'demo-'+Date.now()+'-'+Math.random());
 const body={buyer_reference:$('buyer').value,part_id:$('part').value,machine_model:$('model').value,
 quantity:Number($('qty').value),discount_bps:Math.round(Number($('discount').value)*100),
 tax_bps:Math.round(Number($('tax').value)*100),shipping_paisa:Math.round(Number($('shipping').value)*100),idempotency_key:requestKey};
 try{await api('/api/quotes',body);requestKey=null;await refresh()}catch(e){$('error').textContent=e.message}
 finally{$('create').disabled=false}
});
$('quotes').addEventListener('click',async event=>{
 const button=event.target.closest('button[data-id]');if(!button)return;
 button.disabled=true;$('error').textContent='';
 try{await api('/api/quotes/'+button.dataset.id+'/status',{status:button.dataset.status});await refresh()}
 catch(e){$('error').textContent=e.message;button.disabled=false}
});
$('refresh').addEventListener('click',()=>refresh().catch(e=>$('error').textContent=e.message));
refresh().catch(e=>$('error').textContent=e.message);
