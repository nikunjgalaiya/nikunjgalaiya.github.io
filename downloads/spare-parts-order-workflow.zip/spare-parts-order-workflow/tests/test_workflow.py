import tempfile
import threading
import unittest
from datetime import date,timedelta
from pathlib import Path
from parts_workflow.core import RuleError,catalog,connect,create_quote,init_db,quote,transition

TODAY=date(2026,11,23)
def request(key="example-key-001",qty=2,part="P-101",model="SIM-A100"):
    return dict(buyer_reference="Demo buyer A",part_id=part,machine_model=model,quantity=qty,
      discount_bps=500,tax_bps=1800,shipping_paisa=10000,idempotency_key=key)

class WorkflowTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.path=Path(self.tmp.name)/"test.db"
        self.c=connect(self.path);init_db(self.c)
    def tearDown(self):
        self.c.close();self.tmp.cleanup()
    def draft(self,**kw):return create_quote(self.c,request(**kw),TODAY)
    def move(self,q,status):return transition(self.c,q["quote_id"],status,TODAY)
    def test_quote_arithmetic(self):
        q=self.draft()
        self.assertEqual(q["merchandise_paisa"],250000)
        self.assertEqual(q["discount_paisa"],12500)
        self.assertEqual(q["tax_paisa"],44550)
        self.assertEqual(q["total_paisa"],292050)
    def test_incompatible_part_rejected(self):
        with self.assertRaisesRegex(RuleError,"incompatible"):self.draft(model="SIM-B200")
    def test_zero_quantity_rejected(self):
        with self.assertRaises(RuleError):self.draft(qty=0)
    def test_boolean_quantity_rejected(self):
        with self.assertRaises(RuleError):self.draft(qty=True)
    def test_discount_policy(self):
        p=request();p["discount_bps"]=1001
        with self.assertRaises(RuleError):create_quote(self.c,p,TODAY)
    def test_unknown_part(self):
        with self.assertRaises(RuleError):self.draft(part="X")
    def test_idempotent_retry(self):
        self.assertEqual(self.draft()["quote_id"],self.draft()["quote_id"])
        self.assertEqual(self.c.execute("SELECT COUNT(*) FROM quotes").fetchone()[0],1)
    def test_reused_key_different_request_rejected(self):
        self.draft()
        with self.assertRaisesRegex(RuleError,"different request"):self.draft(qty=3)
    def test_approval_reserves_stock(self):
        q=self.draft();self.move(q,"APPROVED")
        self.assertEqual(catalog(self.c)[0]["available"],10)
    def test_insufficient_stock_rolls_back(self):
        q=self.draft(qty=13)
        with self.assertRaisesRegex(RuleError,"stock"):self.move(q,"APPROVED")
        self.assertEqual(quote(self.c,q["quote_id"])["status"],"DRAFT")
        self.assertEqual(catalog(self.c)[0]["reserved"],0)
    def test_expired_quote_cannot_be_approved(self):
        q=self.draft()
        with self.assertRaisesRegex(RuleError,"expired"):transition(self.c,q["quote_id"],"APPROVED",TODAY+timedelta(days=8))
    def test_validity_includes_seventh_day(self):
        q=self.draft();transition(self.c,q["quote_id"],"APPROVED",TODAY+timedelta(days=7))
    def test_cancellation_releases_reservation(self):
        q=self.draft();self.move(q,"APPROVED");self.move(q,"CANCELLED")
        self.assertEqual(catalog(self.c)[0]["reserved"],0)
        self.assertEqual(catalog(self.c)[0]["on_hand"],12)
    def test_skip_to_dispatch_rejected(self):
        q=self.draft()
        with self.assertRaisesRegex(RuleError,"Cannot move"):self.move(q,"DISPATCHED")
    def test_dispatch_consumes_stock_once(self):
        q=self.draft()
        for status in ["APPROVED","ORDERED","DISPATCHED"]:self.move(q,status)
        self.assertEqual(catalog(self.c)[0]["on_hand"],10)
        self.assertEqual(catalog(self.c)[0]["reserved"],0)
        with self.assertRaises(RuleError):self.move(q,"DISPATCHED")
    def test_delivery_keeps_audit_trail(self):
        q=self.draft()
        for status in ["APPROVED","ORDERED","DISPATCHED","DELIVERED"]:q=self.move(q,status)
        self.assertEqual([e["to_status"] for e in q["events"]],["DRAFT","APPROVED","ORDERED","DISPATCHED","DELIVERED"])
    def test_prices_are_frozen(self):
        q=self.draft();self.c.execute("UPDATE parts SET unit_price_paisa=999999 WHERE part_id='P-101'")
        self.assertEqual(quote(self.c,q["quote_id"])["total_paisa"],292050)
    def test_competing_approvals_do_not_oversell(self):
        a=self.draft(key="concurrent-001",qty=8);b=self.draft(key="concurrent-002",qty=8)
        results=[];barrier=threading.Barrier(2)
        def approve(q):
            c=connect(self.path);barrier.wait()
            try:transition(c,q["quote_id"],"APPROVED",TODAY);results.append("approved")
            except RuleError:results.append("rejected")
            finally:c.close()
        ts=[threading.Thread(target=approve,args=(q,)) for q in [a,b]]
        for t in ts:t.start()
        for t in ts:t.join()
        self.assertCountEqual(results,["approved","rejected"])
        self.assertEqual(catalog(self.c)[0]["reserved"],8)

if __name__=="__main__":unittest.main()
