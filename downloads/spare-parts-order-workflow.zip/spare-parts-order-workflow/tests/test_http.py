"""Exercise the real HTTP boundary using an isolated database and local server."""
import json
import tempfile
import threading
import unittest
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen
from http.server import ThreadingHTTPServer
from parts_workflow.__main__ import make_handler
from parts_workflow.core import connect, init_db


class HTTPTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / "http.db"
        with connect(self.path) as c:
            init_db(c)
        self.server = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(self.path))
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.base = f"http://127.0.0.1:{self.server.server_port}"

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join()
        self.tmp.cleanup()

    def call(self, path, data=None, origin=None):
        headers = {"Content-Type": "application/json"}
        if origin:
            headers["Origin"] = origin
        req = Request(self.base + path, data=None if data is None else json.dumps(data).encode(), headers=headers)
        try:
            response = urlopen(req, timeout=5)
        except HTTPError as error:
            response = error
        with response:
            return response.status, response.read(), response.headers

    def test_static_page_and_assets(self):
        for path, mime in [("/", "text/html"), ("/app.js", "text/javascript"), ("/style.css", "text/css")]:
            status, body, headers = self.call(path)
            self.assertEqual(status, 200)
            self.assertIn(mime, headers["Content-Type"])
            self.assertGreater(len(body), 100)

    def test_quote_round_trip_and_status(self):
        payload = dict(buyer_reference="Demo A", part_id="P-101", machine_model="SIM-A100", quantity=2,
                       discount_bps=500, tax_bps=1800, shipping_paisa=10000, idempotency_key="http-demo-001")
        status, body, _ = self.call("/api/quotes", payload)
        self.assertEqual(status, 201)
        q = json.loads(body)
        self.assertEqual(q["total_paisa"], 292050)
        status, body, _ = self.call(f'/api/quotes/{q["quote_id"]}/status', {"status": "APPROVED"})
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(body)["status"], "APPROVED")
        status, body, _ = self.call("/api/quotes")
        self.assertEqual(status, 200)
        self.assertEqual(len(json.loads(body)), 1)

    def test_cross_origin_write_rejected(self):
        self.assertEqual(self.call("/api/quotes", {}, "https://unrelated.example")[0], 403)

    def test_unknown_path_and_invalid_input(self):
        self.assertEqual(self.call("/../../data/demo.db")[0], 404)
        self.assertEqual(self.call("/api/quotes", [1, 2])[0], 422)
        self.assertEqual(self.call("/api/quotes", {})[0], 422)


if __name__ == "__main__":
    unittest.main()
