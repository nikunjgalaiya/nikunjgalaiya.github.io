# API and data dictionary

| Method and route | Purpose | Result |
|---|---|---|
| GET /api/catalog | Read stock and available quantity | 200, list of parts |
| GET /api/quotes | Latest 100 quotes and audit events | 200, list |
| POST /api/quotes | Create or idempotently retrieve quote | 201, quote |
| POST /api/quotes/{quote_id}/status | Apply valid transition | 200, updated quote |

POST requires application/json and a JSON object of at most 16 KB. Validation errors return 422 with error text. Cross-origin writes return 403, unsupported media 415, unknown routes 404. A replayed create uses 201 for the existing quote by this API's explicit convention.

Creation fields: buyer_reference (non-personal demo label, 1–60 characters), part_id, machine_model, quantity (integer 1–1000), discount_bps (0–1000, default 0), tax_bps (0–10000, default 1800), shipping_paisa (0–1000000, default 10000), idempotency_key (8–100 characters). A basis point is 0.01%; 500 = 5%. Boolean values are not integer quantities.

Money uses integer paisa. Discount = merchandise × discount basis points / 10000, rounded half up to paisa. Taxable amount = merchandise − discount + shipping. Tax uses the same rounding. Total = taxable amount + tax. The 18% default is a demo assumption, not a verified tax classification.

Tables: parts (one row per part, on_hand and reserved); quotes (one part per quote, frozen price totals, status, creation and expiry dates); events (one transition per event, UTC timestamp). Available = on_hand − reserved. The SQL constraint enforces 0 ≤ reserved ≤ on_hand. Approval/dispatch/cancellation use BEGIN IMMEDIATE transactions and rollback on failure.

Quote validity includes the seventh date after creation; server calendar dates determine expiry. Event timestamps are UTC. An identical retry returns the existing quote even after expiry; it does not extend validity or recreate stock reservations.
